<?php

class Constants
{
    const URL_BASE='https://api.altimus.com.br';
    const SENHA_PADRAO='aCY$so3v05i8';

    public function __construct()
    {

    }
}
